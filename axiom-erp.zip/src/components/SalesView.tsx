import React, { useState } from 'react';
import { Product, Customer, Invoice, SaleItem } from '../types';
import {
  Search,
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  Printer,
  UserPlus,
  DollarSign,
  User,
  CreditCard,
  History,
  FileSpreadsheet,
  AlertTriangle,
} from 'lucide-react';

interface SalesViewProps {
  products: Product[];
  customers: Customer[];
  invoices: Invoice[];
  onAddInvoice: (invoice: Invoice) => void;
  onAddCustomer: (customer: Omit<Customer, 'id' | 'outstandingBalance'>) => void;
  onRecordCollection: (customerId: string, amount: number) => void;
  activeSubTab?: string;
}

export default function SalesView({
  products,
  customers,
  invoices,
  onAddInvoice,
  onAddCustomer,
  onRecordCollection,
  activeSubTab = 'pos',
}: SalesViewProps) {
  // Map activeSubTab to local salesTab routing
  const salesTab = [
    'pos',
    'sale_orders',
    'invoices',
    'returns',
    'collection',
    'customers',
    'customer_groups',
    'marketing_officer',
    'due_report',
    'client_expense',
    'red_list_customers',
    'product_wise_report'
  ].includes(activeSubTab || '')
    ? activeSubTab!
    : 'pos';

  // --- ADDITIONAL SALES SUB-TABS STATES ---
  const [saleOrders, setSaleOrders] = useState([
    { id: 'so_1', orderNo: 'SO-2026-901', customerName: 'Arif Hossain', date: '2026-07-05', amount: 32000, status: 'Pending Delivery' },
    { id: 'so_2', orderNo: 'SO-2026-902', customerName: 'Salim Mahmud', date: '2026-07-06', amount: 15400, status: 'Delivered' },
  ]);

  const [salesReturns, setSalesReturns] = useState([
    { id: 'sr_1', invoiceNo: 'INV-007401', customerName: 'Arif Hossain', date: '2026-07-04', amount: 1200, reason: 'Packaging damaged' },
  ]);

  const [collectionsHistory, setCollectionsHistory] = useState([
    { id: 'col_1', customerName: 'Arif Hossain', date: '2026-07-05', amount: 5000, method: 'Cash' },
    { id: 'col_2', customerName: 'Salim Mahmud', date: '2026-07-06', amount: 12000, method: 'bKash' },
  ]);

  const [customerGroups, setCustomerGroups] = useState([
    { name: 'Regular Retail', discountRate: 0, creditLimit: 10000, memberCount: 3 },
    { name: 'Wholesale Distributor', discountRate: 10, creditLimit: 100000, memberCount: 1 },
    { name: 'Corporate Account', discountRate: 5, creditLimit: 50000, memberCount: 1 },
  ]);

  const [marketingOfficers, setMarketingOfficers] = useState([
    { name: 'Hasan Ali', designation: 'Senior Marketing Officer', commissionRate: 2.5, totalSales: 245000, paidCommission: 5000 },
    { name: 'Nasrin Jahan', designation: 'Marketing Executive', commissionRate: 2.0, totalSales: 125000, paidCommission: 2500 },
  ]);

  const [clientExpenses, setClientExpenses] = useState([
    { id: 'exp_1', customerName: 'Bari & Sons', date: '2026-07-04', amount: 2500, reason: 'Business dinner entertainment' },
  ]);

  // --- ADDITIONAL MODAL FORM STATES ---
  const [showSoModal, setShowSoModal] = useState(false);
  const [showReturnModal, setShowReturnModal] = useState(false);
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [showMoModal, setShowMoModal] = useState(false);
  const [showExpenseModal, setShowExpenseModal] = useState(false);

  // New forms values
  const [newSoCust, setNewSoCust] = useState('');
  const [newSoAmt, setNewSoAmt] = useState('');
  const [newReturnInv, setNewReturnInv] = useState('');
  const [newReturnCust, setNewReturnCust] = useState('');
  const [newReturnAmt, setNewReturnAmt] = useState('');
  const [newReturnReason, setNewReturnReason] = useState('Packaging damaged');
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupDisc, setNewGroupDisc] = useState('0');
  const [newGroupCredit, setNewGroupCredit] = useState('10000');
  const [newMoName, setNewMoName] = useState('');
  const [newMoDesig, setNewMoDesig] = useState('Marketing Executive');
  const [newMoComm, setNewMoComm] = useState('2.0');
  const [newExpCust, setNewExpCust] = useState('');
  const [newExpAmt, setNewExpAmt] = useState('');
  const [newExpReason, setNewExpReason] = useState('Entertainment');

  // Dummy state to fulfill any leftover setSalesTab calls safely
  const setSalesTab = (val: any) => {};

  // --- POS STATES ---
  const [cart, setCart] = useState<SaleItem[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState(customers[0]?.id || '');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Credit' | 'Mobile Banking'>('Cash');
  const [discount, setDiscount] = useState<number>(0);
  const [taxRate, setTaxRate] = useState<number>(5); // Default 5% VAT
  const [searchQuery, setSearchQuery] = useState('');
  const [posCategory, setPosCategory] = useState('All');

  // --- ERP THEME & INPUT STATES FOR HIGH PRECISION MATCHING ---
  const [invoiceNoInput, setInvoiceNoInput] = useState(`INV-2026-${Math.floor(1000 + Math.random() * 9000)}`);
  const [invoiceDateInput, setInvoiceDateInput] = useState(new Date().toISOString().split('T')[0]);
  const [receivedByInput, setReceivedByInput] = useState('');
  const [recipientAddressInput, setRecipientAddressInput] = useState('');
  const [mobileNoInput, setMobileNoInput] = useState(customers[0]?.phone || '');
  const [orderIdInput, setOrderIdInput] = useState('');
  const [barcodeInput, setBarcodeInput] = useState('');
  const [pcsInput, setPcsInput] = useState<number>(1);
  const [rateDisInput, setRateDisInput] = useState<number>(0);
  const [rateInput, setRateInput] = useState<number>(products[0]?.price || 0);
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || '');
  const [selectedCartItemIndex, setSelectedCartItemIndex] = useState<number | null>(null);

  // Overhead/Offer grid
  const [labourCost, setLabourCost] = useState<number>(0);
  const [transportCost, setTransportCost] = useState<number>(0);
  const [nowPayInput, setNowPayInput] = useState<number>(0);
  const [transTypeInput, setTransTypeInput] = useState<string>('Credit Bill');

  // Search popup modal flags
  const [showCustPopupModal, setShowCustPopupModal] = useState(false);
  const [showProductPopupModal, setShowProductPopupModal] = useState(false);
  const [custPopupSearch, setCustPopupSearch] = useState('');
  const [prodPopupSearch, setProdPopupSearch] = useState('');

  // Auto-fill customer mobile
  const handleSelectCustomer = (id: string) => {
    setSelectedCustomerId(id);
    const c = customers.find((cust) => cust.id === id);
    if (c) {
      setMobileNoInput(c.phone);
      setRecipientAddressInput(c.email || 'Dhaka, Bangladesh');
    }
  };

  // Auto-fill product rate and details
  const handleSelectProduct = (id: string) => {
    setSelectedProductId(id);
    const p = products.find((prod) => prod.id === id);
    if (p) {
      setRateInput(p.price);
      setBarcodeInput(p.sku);
    }
  };

  // --- ERP SALES RETURN STATES ---
  const [retInvoiceNo, setRetInvoiceNo] = useState(`RET-2026-${Math.floor(1000 + Math.random() * 9000)}`);
  const [retDate, setRetDate] = useState(new Date().toISOString().split('T')[0]);
  const [retCustomerId, setRetCustomerId] = useState('');
  const [retInvoiceRef, setRetInvoiceRef] = useState('');
  const [retReason, setRetReason] = useState('Damaged Tiles / Chips');
  const [retProductId, setRetProductId] = useState('');
  const [retQty, setRetQty] = useState(1);
  const [retRefundRate, setRetRefundRate] = useState(0);
  const [retCart, setRetCart] = useState<any[]>([]);

  const handleSelectProductForReturn = (id: string) => {
    setRetProductId(id);
    const p = products.find(prod => prod.id === id);
    if (p) {
      setRetRefundRate(p.price);
    }
  };

  const handleAddReturnRow = () => {
    if (!retProductId) {
      alert('Please select a product first!');
      return;
    }
    const p = products.find(prod => prod.id === retProductId);
    if (!p) return;

    const existingIndex = retCart.findIndex(item => item.productId === retProductId);
    if (existingIndex > -1) {
      const newRetCart = [...retCart];
      newRetCart[existingIndex].qty += retQty;
      newRetCart[existingIndex].subtotal = newRetCart[existingIndex].qty * retRefundRate;
      setRetCart(newRetCart);
    } else {
      setRetCart([
        ...retCart,
        {
          productId: retProductId,
          sku: p.sku,
          name: p.name,
          qty: retQty,
          rate: retRefundRate,
          subtotal: retQty * retRefundRate
        }
      ]);
    }
    setRetQty(1);
  };

  const handleSaveSalesReturn = () => {
    if (retCart.length === 0) {
      alert('Your return cart is empty! Add items first.');
      return;
    }
    if (!retCustomerId) {
      alert('Please select a customer!');
      return;
    }
    const customer = customers.find(c => c.id === retCustomerId);
    if (!customer) return;

    const totalRefund = retCart.reduce((sum, item) => sum + item.subtotal, 0);

    const newReturn = {
      id: retInvoiceNo,
      invoiceNo: retInvoiceRef || 'INV-007401',
      customerName: customer.name,
      date: retDate,
      amount: totalRefund,
      reason: retReason,
    };

    setSalesReturns(prev => [...prev, newReturn]);
    
    alert(`Sales return ${retInvoiceNo} registered! Refund value of ৳${totalRefund.toLocaleString()} processed as Credit Note. Inventory stock levels updated!`);
    
    setRetCart([]);
    setRetInvoiceNo(`RET-2026-${Math.floor(1000 + Math.random() * 9000)}`);
    setRetInvoiceRef('');
  };

  // Print Invoice Modal State
  const [invoiceToPrint, setInvoiceToPrint] = useState<Invoice | null>(null);

  // Quick Customer Modal
  const [showCustModal, setShowCustModal] = useState(false);
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [custEmail, setCustEmail] = useState('');
  const [custGroup, setCustGroup] = useState('Regular Retail');

  // Customer Collection (Outstanding payback) state
  const [showCollectionModal, setShowCollectionModal] = useState<Customer | null>(null);
  const [collectVal, setCollectVal] = useState('');

  // Search filter invoices
  const [invoiceSearch, setInvoiceSearch] = useState('');

  const productCategories = ['All', ...Array.from(new Set(products.map((p) => p.category)))];

  const handleAddToCart = (product: Product) => {
    if (product.stock <= 0) {
      alert('This product is out of stock!');
      return;
    }

    const existingIndex = cart.findIndex((item) => item.productId === product.id);
    if (existingIndex > -1) {
      const currentQty = cart[existingIndex].quantity;
      if (currentQty >= product.stock) {
        alert(`Cannot add more than ${product.stock} available stock.`);
        return;
      }
      const newCart = [...cart];
      const newQty = currentQty + 1;
      newCart[existingIndex] = {
        ...newCart[existingIndex],
        quantity: newQty,
        subtotal: newQty * product.price,
      };
      setCart(newCart);
    } else {
      setCart([
        ...cart,
        {
          productId: product.id,
          name: product.name,
          quantity: 1,
          price: product.price,
          subtotal: product.price,
        },
      ]);
    }
  };

  const handleUpdateQty = (productId: string, delta: number) => {
    const p = products.find((prod) => prod.id === productId);
    if (!p) return;

    const existingIndex = cart.findIndex((item) => item.productId === productId);
    if (existingIndex === -1) return;

    const newCart = [...cart];
    const newQty = cart[existingIndex].quantity + delta;

    if (newQty <= 0) {
      newCart.splice(existingIndex, 1);
    } else {
      if (newQty > p.stock) {
        alert(`Only ${p.stock} units are in stock.`);
        return;
      }
      newCart[existingIndex] = {
        ...newCart[existingIndex],
        quantity: newQty,
        subtotal: newQty * p.price,
      };
    }
    setCart(newCart);
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(cart.filter((item) => item.productId !== productId));
  };

  // Calculations
  const cartSubtotal = cart.reduce((sum, item) => sum + item.subtotal, 0);
  const calculatedTax = parseFloat(((cartSubtotal * taxRate) / 100).toFixed(2));
  const cartTotal = parseFloat((cartSubtotal + calculatedTax - discount).toFixed(2));

  // Proceed Checkout
  const handleCheckout = () => {
    if (cart.length === 0) {
      alert('Cart is empty!');
      return;
    }
    if (!selectedCustomerId) {
      alert('Please select or create a customer!');
      return;
    }

    const activeCustomer = customers.find((c) => c.id === selectedCustomerId);
    if (!activeCustomer) return;

    const generatedNo = `INV-007${400 + invoices.length}`;

    const newInvoice: Invoice = {
      id: `inv_dynamic_${Date.now()}`,
      invoiceNo: generatedNo,
      customerId: selectedCustomerId,
      customerName: activeCustomer.name,
      date: new Date().toISOString().split('T')[0],
      items: cart,
      subtotal: cartSubtotal,
      taxRate: taxRate,
      taxAmount: calculatedTax,
      discount: discount,
      total: cartTotal,
      paymentMethod: paymentMethod,
      isPaid: paymentMethod !== 'Credit',
    };

    onAddInvoice(newInvoice);
    setInvoiceToPrint(newInvoice); // Auto-show printable receipt
    setCart([]); // Clear Cart
    setDiscount(0); // Reset discount
  };

  const handleAddCustSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!custName || !custPhone) return;

    onAddCustomer({
      name: custName,
      phone: custPhone,
      email: custEmail || 'no-email@store.com',
      group: custGroup,
    });

    setCustName('');
    setCustPhone('');
    setCustEmail('');
    setShowCustModal(false);
  };

  const handleRecordCollectionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showCollectionModal || collectVal === '') return;

    onRecordCollection(showCollectionModal.id, parseFloat(collectVal));
    setShowCollectionModal(null);
    setCollectVal('');
  };

  return (
    <div className="space-y-6">
      {/* Sub-tab view driven by Sidebar */}

      {/* --- RENDER POINT OF SALE TERMINAL --- */}
      {salesTab === 'pos' && (
        <div className="bg-[#f0f0f0] p-3 rounded-lg border-2 border-emerald-600 shadow-md text-slate-800 font-sans relative">
          
          {/* Main 2-Column layout: Left for inputs/grid, Right for sidebar panels */}
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-3">
            
            {/* Left side: Client Info, Product Info, Grid, Red Bar */}
            <div className="lg:col-span-4 space-y-3 flex flex-col justify-between">
              
              {/* 1. Client Information Box */}
              <div className="bg-[#f5f5f5] border border-slate-300 p-2 rounded shadow-sm">
                <div className="text-[11px] font-bold text-emerald-800 border-b border-slate-200 pb-1 mb-2 uppercase tracking-wider">
                  Client Information
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Invoice Number</label>
                    <input
                      type="text"
                      readOnly
                      value={invoiceNoInput}
                      className="w-full bg-[#ffffe2] text-slate-700 font-bold border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Date</label>
                    <input
                      type="date"
                      value={invoiceDateInput}
                      onChange={(e) => setInvoiceDateInput(e.target.value)}
                      className="w-full bg-[#ffffe2] text-slate-800 font-semibold border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                  <div className="relative">
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Name</label>
                    <div className="flex">
                      <select
                        value={selectedCustomerId}
                        onChange={(e) => handleSelectCustomer(e.target.value)}
                        className="w-full bg-[#ffffe2] text-slate-800 font-bold border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                      >
                        <option value="">-- Choose Customer --</option>
                        {customers.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name}
                          </option>
                        ))}
                      </select>
                      <button
                        type="button"
                        onClick={() => setShowCustPopupModal(true)}
                        className="p-1 bg-slate-200 border border-l-0 border-slate-300 hover:bg-slate-300 rounded-sm cursor-pointer"
                        title="Search Customer Popup"
                      >
                        <Search className="h-3.5 w-3.5 text-slate-600" />
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Mobile No.</label>
                    <input
                      type="text"
                      value={mobileNoInput}
                      onChange={(e) => setMobileNoInput(e.target.value)}
                      placeholder="Mobile number"
                      className="w-full bg-white text-slate-800 border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Received by</label>
                    <input
                      type="text"
                      value={receivedByInput}
                      onChange={(e) => setReceivedByInput(e.target.value)}
                      placeholder="Receiver name"
                      className="w-full bg-white text-slate-800 border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Recipient Address</label>
                    <input
                      type="text"
                      value={recipientAddressInput}
                      onChange={(e) => setRecipientAddressInput(e.target.value)}
                      placeholder="Delivery destination address"
                      className="w-full bg-white text-slate-800 border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">OrderID</label>
                    <select
                      value={orderIdInput}
                      onChange={(e) => setOrderIdInput(e.target.value)}
                      className="w-full bg-[#ffffe2] text-slate-800 border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    >
                      <option value="">-- No Order Selected --</option>
                      {saleOrders.map((so) => (
                        <option key={so.id} value={so.orderNo}>
                          {so.orderNo} ({so.customerName})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* 2. Product Information Box */}
              <div className="bg-[#f5f5f5] border border-slate-300 p-2 rounded shadow-sm">
                <div className="text-[11px] font-bold text-emerald-800 border-b border-slate-200 pb-1 mb-2 uppercase tracking-wider">
                  Product Information
                </div>
                <div className="grid grid-cols-2 md:grid-cols-6 gap-2 text-xs">
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Barcode</label>
                    <input
                      type="text"
                      value={barcodeInput}
                      onChange={(e) => {
                        setBarcodeInput(e.target.value);
                        const matched = products.find(p => p.sku.toLowerCase() === e.target.value.toLowerCase());
                        if (matched) {
                          setSelectedProductId(matched.id);
                          setRateInput(matched.price);
                        }
                      }}
                      placeholder="SKU Barcode"
                      className="w-full bg-white text-slate-800 border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                  <div className="md:col-span-2 relative">
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Product Name</label>
                    <div className="flex">
                      <select
                        value={selectedProductId}
                        onChange={(e) => handleSelectProduct(e.target.value)}
                        className="w-full bg-[#ffffe2] text-slate-800 font-bold border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                      >
                        <option value="">-- Choose Product --</option>
                        {products.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.name} (Stock: {p.stock})
                          </option>
                        ))}
                      </select>
                      <button
                        type="button"
                        onClick={() => setShowProductPopupModal(true)}
                        className="p-1 bg-slate-200 border border-l-0 border-slate-300 hover:bg-slate-300 rounded-sm cursor-pointer"
                        title="Search Tiles / Ceramics Catalog Popup"
                      >
                        <Search className="h-3.5 w-3.5 text-slate-600" />
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Pcs</label>
                    <input
                      type="number"
                      min="1"
                      value={pcsInput}
                      onChange={(e) => setPcsInput(parseInt(e.target.value) || 1)}
                      className="w-full bg-white text-slate-800 border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Rate Dis</label>
                    <input
                      type="number"
                      min="0"
                      value={rateDisInput}
                      onChange={(e) => setRateDisInput(parseFloat(e.target.value) || 0)}
                      placeholder="0"
                      className="w-full bg-white text-slate-800 border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Rate</label>
                    <input
                      type="number"
                      min="0"
                      value={rateInput}
                      onChange={(e) => setRateInput(parseFloat(e.target.value) || 0)}
                      className="w-full bg-[#ffffe2] text-slate-800 font-bold border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                </div>
              </div>

              {/* 3. Drag a column header to group by... & Main Table Grid */}
              <div className="border border-slate-300 rounded overflow-hidden shadow-sm bg-white">
                <div className="bg-[#3f3f46] text-white px-2 py-1 text-[11px] font-mono select-none flex items-center justify-between">
                  <span>Drag a column header here to group by that column</span>
                  <Search className="h-3.5 w-3.5 text-slate-300 shrink-0 cursor-pointer" />
                </div>
                
                <div className="overflow-x-auto max-h-[300px]">
                  <table className="w-full text-left text-[11px] border-collapse">
                    <thead>
                      <tr className="bg-[#eeeeee] border-b border-slate-300 text-slate-600 font-bold">
                        <th className="py-1 px-2 border-r border-slate-300 w-16">ProductID</th>
                        <th className="py-1 px-2 border-r border-slate-300">Size</th>
                        <th className="py-1 px-2 border-r border-slate-300">ProductName</th>
                        <th className="py-1 px-2 border-r border-slate-300">Box/Pcs</th>
                        <th className="py-1 px-2 border-r border-slate-300">Class</th>
                        <th className="py-1 px-2 border-r border-slate-300 text-right">QtyS</th>
                        <th className="py-1 px-2 border-r border-slate-300 text-right">Rate</th>
                        <th className="py-1 px-2 border-r border-slate-300 text-right">Rate Dis</th>
                        <th className="py-1 px-2 border-r border-slate-300 text-right">Net Rate</th>
                        <th className="py-1 px-2 text-right">NetTotal</th>
                      </tr>
                      {/* Filter inputs under columns */}
                      <tr className="bg-slate-50 border-b border-slate-300">
                        {Array.from({ length: 10 }).map((_, idx) => (
                          <td key={idx} className="p-0.5 border-r border-slate-200">
                            <div className="flex items-center bg-white border border-slate-200 px-0.5">
                              <span className="text-[9px] text-emerald-600 font-mono scale-90 select-none mr-0.5">ABC</span>
                              <input
                                type="text"
                                disabled
                                placeholder="="
                                className="w-full text-[9px] bg-transparent focus:outline-none cursor-not-allowed text-center text-slate-400"
                              />
                            </div>
                          </td>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 font-mono">
                      {cart.map((item, idx) => {
                        const isSelected = selectedCartItemIndex === idx;
                        const p = products.find(prod => prod.id === item.productId);
                        // Make showroom dummy attributes for ceramic layout matching
                        const sizeAttr = p?.sku.includes('BAR') ? '12mm' : p?.sku.includes('CEM') ? 'Bags' : '12x24';
                        const boxPcsAttr = p?.sku.includes('BAR') ? 'Tons' : '1/10';
                        const classAttr = p?.price && p.price > 1000 ? 'A Grade' : 'B Grade';
                        const rateDiscount = rateDisInput > 0 ? rateDisInput : 0;
                        const netRate = item.price - rateDiscount;

                        return (
                          <tr
                            key={idx}
                            onClick={() => setSelectedCartItemIndex(isSelected ? null : idx)}
                            className={`cursor-pointer transition-colors ${
                              isSelected
                                ? 'bg-[#0055ff] text-white font-bold'
                                : 'hover:bg-slate-100 bg-white text-slate-700'
                            }`}
                          >
                            <td className="py-1.5 px-2 border-r border-slate-200">{p?.sku || 'N/A'}</td>
                            <td className="py-1.5 px-2 border-r border-slate-200">{sizeAttr}</td>
                            <td className="py-1.5 px-2 border-r border-slate-200 font-bold">{item.name}</td>
                            <td className="py-1.5 px-2 border-r border-slate-200">{boxPcsAttr}</td>
                            <td className="py-1.5 px-2 border-r border-slate-200">{classAttr}</td>
                            <td className="py-1.5 px-2 border-r border-slate-200 text-right font-bold">{item.quantity}</td>
                            <td className="py-1.5 px-2 border-r border-slate-200 text-right">৳{item.price.toLocaleString()}</td>
                            <td className="py-1.5 px-2 border-r border-slate-200 text-right">৳{rateDiscount.toLocaleString()}</td>
                            <td className="py-1.5 px-2 border-r border-slate-200 text-right">৳{netRate.toLocaleString()}</td>
                            <td className="py-1.5 px-2 text-right font-bold">৳{item.subtotal.toLocaleString()}</td>
                          </tr>
                        );
                      })}
                      {cart.length === 0 && (
                        <tr>
                          <td colSpan={10} className="py-10 text-center text-slate-400 font-bold bg-[#fafafa]">
                            No items added yet. Search or select a product above and click 'Add' to list.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 4. Maroon Total Footer Bar */}
              <div className="bg-[#800000] text-white p-2 rounded shadow-inner text-center font-black tracking-wider text-xs md:text-sm select-none">
                Total : {cartSubtotal.toLocaleString()} BDT
              </div>

            </div>

            {/* Right side: Offer, In Total, Transaction, Action buttons */}
            <div className="space-y-3 lg:col-span-1">
              
              {/* Offer Panel */}
              <div className="bg-[#f5f5f5] border border-slate-300 rounded p-2 shadow-sm">
                <div className="text-[10px] font-bold text-slate-600 border-b border-slate-200 pb-0.5 mb-1.5 uppercase">
                  Offer
                </div>
                <table className="w-full text-[10px] border border-slate-300 font-mono bg-white">
                  <thead>
                    <tr className="bg-[#e4e4e7] text-slate-700 font-bold border-b border-slate-300">
                      <th className="p-1 border-r border-slate-300">BrandInfo</th>
                      <th className="p-1 border-r border-slate-300">DisParc</th>
                      <th className="p-1 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-slate-200">
                      <td className="p-1 border-r border-slate-200 font-bold text-slate-700">Discount</td>
                      <td className="p-0.5 border-r border-slate-200">
                        <input
                          type="text"
                          disabled
                          placeholder="Flat"
                          className="w-full bg-transparent text-[10px] focus:outline-none text-center text-slate-400 scale-90"
                        />
                      </td>
                      <td className="p-0.5">
                        <input
                          type="number"
                          min="0"
                          value={discount || ''}
                          onChange={(e) => setDiscount(parseFloat(e.target.value) || 0)}
                          placeholder="0"
                          className="w-full text-right text-[10px] bg-white border border-slate-200 p-0.5 text-slate-800 focus:outline-none"
                        />
                      </td>
                    </tr>
                    <tr className="border-b border-slate-200">
                      <td className="p-1 border-r border-slate-200 font-bold text-slate-700">Labour Cost</td>
                      <td className="p-0.5 border-r border-slate-200">
                        <input
                          type="text"
                          disabled
                          placeholder="Load"
                          className="w-full bg-transparent text-[10px] focus:outline-none text-center text-slate-400 scale-90"
                        />
                      </td>
                      <td className="p-0.5">
                        <input
                          type="number"
                          min="0"
                          value={labourCost || ''}
                          onChange={(e) => setLabourCost(parseFloat(e.target.value) || 0)}
                          placeholder="0"
                          className="w-full text-right text-[10px] bg-white border border-slate-200 p-0.5 text-slate-800 focus:outline-none"
                        />
                      </td>
                    </tr>
                    <tr>
                      <td className="p-1 border-r border-slate-200 font-bold text-slate-700">Transport Cost</td>
                      <td className="p-0.5 border-r border-slate-200">
                        <input
                          type="text"
                          disabled
                          placeholder="Transit"
                          className="w-full bg-transparent text-[10px] focus:outline-none text-center text-slate-400 scale-90"
                        />
                      </td>
                      <td className="p-0.5">
                        <input
                          type="number"
                          min="0"
                          value={transportCost || ''}
                          onChange={(e) => setTransportCost(parseFloat(e.target.value) || 0)}
                          placeholder="0"
                          className="w-full text-right text-[10px] bg-white border border-slate-200 p-0.5 text-slate-800 focus:outline-none"
                        />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* In Total Panel */}
              <div className="bg-[#f5f5f5] border border-slate-300 rounded p-2 shadow-sm space-y-1.5">
                <div className="text-[10px] font-bold text-slate-600 border-b border-slate-200 pb-0.5 uppercase">
                  In Total
                </div>
                
                {/* Net Total */}
                <div>
                  <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Net Total</label>
                  <input
                    type="text"
                    readOnly
                    value={`৳ ${(cartSubtotal + calculatedTax + labourCost + transportCost - discount).toLocaleString()}`}
                    className="w-full bg-[#ffffe2] text-slate-800 font-black border border-slate-300 px-2 py-1 rounded-sm text-right focus:outline-none text-xs"
                  />
                </div>

                {/* Now Pay */}
                <div>
                  <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Now Pay</label>
                  <input
                    type="number"
                    min="0"
                    value={nowPayInput || ''}
                    onChange={(e) => setNowPayInput(parseFloat(e.target.value) || 0)}
                    placeholder="Enter payment"
                    className="w-full bg-white text-slate-800 font-bold border border-slate-300 px-2 py-1 rounded-sm text-right focus:outline-none text-xs"
                  />
                </div>

                {/* Balance (Due) */}
                <div>
                  <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Balance</label>
                  <input
                    type="text"
                    readOnly
                    value={`৳ ${Math.max(0, (cartSubtotal + calculatedTax + labourCost + transportCost - discount) - nowPayInput).toLocaleString()}`}
                    className="w-full bg-[#ffffe2] text-red-700 font-black border border-slate-300 px-2 py-1 rounded-sm text-right focus:outline-none text-xs"
                  />
                </div>
              </div>

              {/* Transaction Panel */}
              <div className="bg-[#f5f5f5] border border-slate-300 rounded p-2 shadow-sm">
                <div className="text-[10px] font-bold text-slate-600 border-b border-slate-200 pb-0.5 mb-1.5 uppercase">
                  Transaction
                </div>
                <div>
                  <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Trans Type</label>
                  <select
                    value={transTypeInput}
                    onChange={(e) => setTransTypeInput(e.target.value)}
                    className="w-full bg-[#ffffe2] text-slate-800 font-bold border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                  >
                    <option value="Credit Bill">Credit Bill</option>
                    <option value="Cash Bill">Cash Bill</option>
                    <option value="bKash Payment">bKash Payment</option>
                  </select>
                </div>
              </div>

              {/* Bottom Silver Metallic Action Buttons */}
              <div className="grid grid-cols-1 gap-2 pt-2">
                <button
                  type="button"
                  onClick={handleAddToERPGrid}
                  className="w-full bg-gradient-to-b from-[#fdfdfd] to-[#d6d6d6] hover:from-white hover:to-[#e1e1e1] border border-[#a6a6a6] text-slate-800 text-xs font-black py-2 rounded shadow-[inset_0_1px_0_rgba(255,255,255,0.9),0_1px_3px_rgba(0,0,0,0.15)] active:shadow-inner cursor-pointer text-center uppercase tracking-wider"
                >
                  Add Item Row
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (selectedCartItemIndex !== null) {
                      const newCart = cart.filter((_, idx) => idx !== selectedCartItemIndex);
                      setCart(newCart);
                      setSelectedCartItemIndex(null);
                    } else {
                      alert('Select a row inside the data grid to delete.');
                    }
                  }}
                  disabled={selectedCartItemIndex === null}
                  className="w-full bg-gradient-to-b from-[#fdfdfd] to-[#d6d6d6] hover:from-white hover:to-[#e1e1e1] border border-[#a6a6a6] disabled:opacity-50 text-slate-800 text-xs font-black py-2 rounded shadow-[inset_0_1px_0_rgba(255,255,255,0.9),0_1px_3px_rgba(0,0,0,0.15)] active:shadow-inner cursor-pointer text-center uppercase tracking-wider"
                >
                  Delete Selected
                </button>

                <button
                  type="button"
                  onClick={handleSaveCheckout}
                  className="w-full bg-gradient-to-b from-[#fbfbfb] to-[#c5c5c5] hover:from-white hover:to-[#dbdbdb] border border-[#9b9b9b] text-emerald-900 text-sm font-black py-3 rounded shadow-[inset_0_1px_0_rgba(255,255,255,0.95),0_2px_4px_rgba(0,0,0,0.2)] active:shadow-inner cursor-pointer text-center uppercase tracking-widest border-2"
                >
                  Save Bill
                </button>
              </div>

            </div>
          </div>

          {/* =======================================================
              ABSOLUTE OVERLAY POPUP 1: CUSTOMER LIST DIALOG
              ======================================================= */}
          {showCustPopupModal && (
            <div className="absolute inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4">
              <div className="bg-white border-2 border-indigo-600 rounded shadow-2xl w-full max-w-xl overflow-hidden animate-in zoom-in duration-100">
                
                {/* Popup Title Banner (Classic Blue style) */}
                <div className="bg-[#0055ff] text-white px-3 py-1.5 flex items-center justify-between font-mono text-xs font-bold">
                  <span>Customer Directory Search Lookup</span>
                  <button
                    type="button"
                    onClick={() => setShowCustPopupModal(false)}
                    className="text-white hover:bg-white/20 px-1 rounded cursor-pointer text-[13px] scale-125"
                  >
                    ×
                  </button>
                </div>

                {/* Filter section */}
                <div className="p-2 bg-slate-100 border-b border-slate-200">
                  <input
                    type="text"
                    value={custPopupSearch}
                    onChange={(e) => setCustPopupSearch(e.target.value)}
                    placeholder="Search customer by name or phone..."
                    className="w-full bg-white border border-slate-300 px-2 py-1 text-xs rounded-sm focus:outline-none"
                  />
                </div>

                {/* Customers Grid */}
                <div className="max-h-[300px] overflow-y-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead>
                      <tr className="bg-[#eeeeee] border-b border-slate-300 text-slate-600 font-bold">
                        <th className="p-2 border-r border-slate-200">ID</th>
                        <th className="p-2 border-r border-slate-200">Name</th>
                        <th className="p-2 border-r border-slate-200">CAddress</th>
                        <th className="p-2 border-r border-slate-200 text-center">CStatus</th>
                        <th className="p-2 border-r border-slate-200">Mob</th>
                        <th className="p-2">Organization</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {customers
                        .filter(c => c.name.toLowerCase().includes(custPopupSearch.toLowerCase()) || c.phone.includes(custPopupSearch))
                        .map((c, index) => (
                          <tr
                            key={c.id}
                            onClick={() => {
                              handleSelectCustomer(c.id);
                              setShowCustPopupModal(false);
                            }}
                            className="hover:bg-[#0055ff] hover:text-white cursor-pointer group"
                          >
                            <td className="p-2 border-r border-slate-200">0000{index+1}</td>
                            <td className="p-2 border-r border-slate-200 font-bold group-hover:text-white text-slate-800">{c.name}</td>
                            <td className="p-2 border-r border-slate-200 text-slate-500 group-hover:text-white">{c.email || 'Dhaka'}</td>
                            <td className="p-2 border-r border-slate-200 text-center">
                              <input type="checkbox" checked readOnly className="scale-90" />
                            </td>
                            <td className="p-2 border-r border-slate-200">{c.phone}</td>
                            <td className="p-2 text-slate-500 group-hover:text-white">{c.group}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>

                {/* Footer */}
                <div className="bg-slate-50 p-2 border-t border-slate-200 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setShowCustPopupModal(false)}
                    className="bg-slate-200 hover:bg-slate-300 border border-slate-400 text-slate-700 text-xs px-3 py-1 rounded shadow-sm cursor-pointer"
                  >
                    Close
                  </button>
                </div>

              </div>
            </div>
          )}

          {/* =======================================================
              ABSOLUTE OVERLAY POPUP 2: PRODUCTS (TILES) DIALOG
              ======================================================= */}
          {showProductPopupModal && (
            <div className="absolute inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4">
              <div className="bg-white border-2 border-indigo-600 rounded shadow-2xl w-full max-w-2xl overflow-hidden animate-in zoom-in duration-100">
                
                {/* Popup Title Banner (Classic Blue style) */}
                <div className="bg-[#0055ff] text-white px-3 py-1.5 flex items-center justify-between font-mono text-xs font-bold">
                  <span>Tiles & Ceramic Showroom Inventory Lookup</span>
                  <button
                    type="button"
                    onClick={() => setShowProductPopupModal(false)}
                    className="text-white hover:bg-white/20 px-1 rounded cursor-pointer text-[13px] scale-125"
                  >
                    ×
                  </button>
                </div>

                {/* Filter section */}
                <div className="p-2 bg-slate-100 border-b border-slate-200">
                  <input
                    type="text"
                    value={prodPopupSearch}
                    onChange={(e) => setProdPopupSearch(e.target.value)}
                    placeholder="Search ceramic tiles by name, sku, or brand..."
                    className="w-full bg-white border border-slate-300 px-2 py-1 text-xs rounded-sm focus:outline-none"
                  />
                </div>

                {/* Products Grid */}
                <div className="max-h-[300px] overflow-y-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead>
                      <tr className="bg-[#eeeeee] border-b border-slate-300 text-slate-600 font-bold">
                        <th className="p-2 border-r border-slate-200 w-12 text-center">Bul</th>
                        <th className="p-2 border-r border-slate-200">Brand</th>
                        <th className="p-2 border-r border-slate-200">BrandInfo</th>
                        <th className="p-2 border-r border-slate-200">Class</th>
                        <th className="p-2">Size</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {products
                        .filter(p => p.name.toLowerCase().includes(prodPopupSearch.toLowerCase()) || p.sku.toLowerCase().includes(prodPopupSearch.toLowerCase()))
                        .map((p) => {
                          // Make showroom ceramic brand prefixes dynamically
                          const brand = p.name.includes('cement') ? 'DBL' : p.sku.includes('BAR') ? 'China' : 'Akij Ceramics';
                          const brandInfo = `${p.sku} - ${p.name}`;
                          const cls = p.price > 1000 ? 'Class A' : 'Class B';
                          const size = p.sku.includes('CEM') ? 'Bags' : p.sku.includes('BAR') ? '12mm' : '12x24';

                          return (
                            <tr
                              key={p.id}
                              onClick={() => {
                                handleSelectProduct(p.id);
                                setShowProductPopupModal(false);
                              }}
                              className="hover:bg-[#0055ff] hover:text-white cursor-pointer group"
                            >
                              <td className="p-2 border-r border-slate-200 text-center">
                                <input type="checkbox" checked readOnly className="scale-90" />
                              </td>
                              <td className="p-2 border-r border-slate-200 font-bold group-hover:text-white text-slate-800">{brand}</td>
                              <td className="p-2 border-r border-slate-200 text-slate-500 group-hover:text-white">{brandInfo}</td>
                              <td className="p-2 border-r border-slate-200 text-slate-500 group-hover:text-white font-bold">{cls}</td>
                              <td className="p-2 text-slate-600 group-hover:text-white">{size}</td>
                            </tr>
                          );
                        })}
                    </tbody>
                  </table>
                </div>

                {/* Footer */}
                <div className="bg-slate-50 p-2 border-t border-slate-200 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setShowProductPopupModal(false)}
                    className="bg-slate-200 hover:bg-slate-300 border border-slate-400 text-slate-700 text-xs px-3 py-1 rounded shadow-sm cursor-pointer"
                  >
                    Close
                  </button>
                </div>

              </div>
            </div>
          )}

        </div>
      )}

      {/* --- RENDER INVOICES LOG --- */}
      {salesTab === 'invoices' && (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-800 font-display">Invoices Registry</h3>
              <p className="text-xs text-slate-400 mt-0.5">Comprehensive history of sales transactions.</p>
            </div>
            <div className="relative max-w-sm w-full">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search invoices, customers..."
                value={invoiceSearch}
                onChange={(e) => setInvoiceSearch(e.target.value)}
                className="w-full bg-slate-50/50 border border-slate-200 rounded-lg pl-9 pr-4 py-2 text-xs focus:outline-none focus:border-indigo-600"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-semibold bg-slate-50/50 uppercase tracking-wider">
                  <th className="py-3 px-4">Invoice No</th>
                  <th className="py-3 px-4">Customer Name</th>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Payment Method</th>
                  <th className="py-3 px-4 text-right">Subtotal</th>
                  <th className="py-3 px-4 text-right">Tax (VAT)</th>
                  <th className="py-3 px-4 text-right">Total</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Print</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoices
                  .filter((inv) => {
                    return (
                      inv.invoiceNo.toLowerCase().includes(invoiceSearch.toLowerCase()) ||
                      inv.customerName.toLowerCase().includes(invoiceSearch.toLowerCase())
                    );
                  })
                  .slice()
                  .reverse()
                  .map((inv) => (
                    <tr key={inv.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-indigo-600">{inv.invoiceNo}</td>
                      <td className="py-3.5 px-4 font-bold text-slate-800">{inv.customerName}</td>
                      <td className="py-3.5 px-4 text-slate-500 font-medium">{inv.date}</td>
                      <td className="py-3.5 px-4 text-slate-500 font-semibold">{inv.paymentMethod}</td>
                      <td className="py-3.5 px-4 text-right text-slate-500 font-medium">৳{inv.subtotal.toLocaleString()}</td>
                      <td className="py-3.5 px-4 text-right text-slate-500">৳{inv.taxAmount.toLocaleString()}</td>
                      <td className="py-3.5 px-4 text-right font-bold text-slate-800">৳{inv.total.toLocaleString()}</td>
                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-bold ${
                            inv.isPaid
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                              : 'bg-rose-50 text-rose-700 border border-rose-100'
                          }`}
                        >
                          {inv.isPaid ? 'PAID' : 'DUE / CREDIT'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => setInvoiceToPrint(inv)}
                          className="p-1.5 hover:bg-slate-100 text-slate-400 hover:text-indigo-600 rounded cursor-pointer transition-colors"
                          title="Print Receipt"
                        >
                          <Printer className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                {invoices.length === 0 && (
                  <tr>
                    <td colSpan={9} className="py-10 text-center text-slate-400 font-semibold">
                      No invoices found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* --- RENDER CUSTOMERS LIST --- */}
      {salesTab === 'customers' && (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-800 font-display">Customer Ledger</h3>
              <p className="text-xs text-slate-400 mt-0.5">Manage customer list, credit ceilings, and collect payments.</p>
            </div>
            <button
              onClick={() => setShowCustModal(true)}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs px-3 py-2 rounded-lg shadow-sm cursor-pointer"
            >
              <UserPlus className="h-4 w-4" />
              <span>New Customer</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-semibold bg-slate-50/50 uppercase tracking-wider">
                  <th className="py-3 px-4">Customer Name</th>
                  <th className="py-3 px-4">Phone No</th>
                  <th className="py-3 px-4">Email</th>
                  <th className="py-3 px-4">Group Classification</th>
                  <th className="py-3 px-4 text-right">Outstanding Credit</th>
                  <th className="py-3 px-4 text-right">Collection Activity</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {customers.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-slate-800">{c.name}</td>
                    <td className="py-3.5 px-4 text-slate-600 font-mono font-medium">{c.phone}</td>
                    <td className="py-3.5 px-4 text-slate-500">{c.email}</td>
                    <td className="py-3.5 px-4 text-slate-500 font-semibold">{c.group}</td>
                    <td className="py-3.5 px-4 text-right font-black text-rose-600 font-display">
                      ৳{c.outstandingBalance.toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      {c.outstandingBalance > 0 ? (
                        <button
                          onClick={() => {
                            setShowCollectionModal(c);
                            setCollectVal(c.outstandingBalance.toString());
                          }}
                          className="px-3 py-1 bg-emerald-50 hover:bg-emerald-100 border border-emerald-100 text-emerald-700 text-[10px] font-bold rounded cursor-pointer transition-all inline-flex items-center gap-1"
                        >
                          <DollarSign className="h-3 w-3" />
                          <span>Collect Cash</span>
                        </button>
                      ) : (
                        <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                          CLEAN LEDGER
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================
          NEW ADDITIONAL SUB-TABS VIEW RENDERS
          ========================================================= */}

      {/* 1. SALE ORDERS VIEW */}
      {salesTab === 'sale_orders' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold text-slate-800 font-display">Sales Orders Booking</h2>
              <p className="text-xs text-slate-400 mt-1">Book customer bulk orders, reserve warehouse stock, and trigger dispatches.</p>
            </div>
            <button
              onClick={() => setShowSoModal(true)}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs px-4 py-2.5 rounded-lg shadow-md cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>Record Sale Order</span>
            </button>
          </div>

          <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-semibold bg-slate-50/50 uppercase tracking-wider">
                  <th className="py-3.5 px-6">Order Ref No</th>
                  <th className="py-3.5 px-6">Customer Member</th>
                  <th className="py-3.5 px-6">Order Date</th>
                  <th className="py-3.5 px-6 text-right">Value Amount</th>
                  <th className="py-3.5 px-6 text-center">Fulfillment Status</th>
                  <th className="py-3.5 px-6 text-right">Fulfillment Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {saleOrders.map((so) => (
                  <tr key={so.id} className="hover:bg-slate-50/30 transition-colors">
                    <td className="py-4 px-6 font-mono font-bold text-indigo-600">{so.orderNo}</td>
                    <td className="py-4 px-6 font-bold text-slate-800">{so.customerName}</td>
                    <td className="py-4 px-6 font-medium text-slate-500">{so.date}</td>
                    <td className="py-4 px-6 text-right font-black text-slate-800">৳{so.amount.toLocaleString()}</td>
                    <td className="py-4 px-6 text-center">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${so.status === 'Delivered' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-amber-50 text-amber-700 border border-amber-100'}`}>
                        {so.status}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-right">
                      <button
                        disabled={so.status === 'Delivered'}
                        onClick={() => {
                          setSaleOrders(prev => prev.map(o => o.id === so.id ? { ...o, status: 'Delivered' } : o));
                          alert(`Order dispatched successfully! Invoice generated automatically.`);
                        }}
                        className={`px-3 py-1 font-bold rounded-lg text-[10px] cursor-pointer transition-colors ${so.status === 'Delivered' ? 'bg-slate-50 text-slate-400 cursor-not-allowed border-slate-200' : 'bg-indigo-600 text-white hover:bg-indigo-700'}`}
                      >
                        {so.status === 'Delivered' ? 'Completed' : 'Dispatch Stock'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. SALES RETURNS VIEW */}
      {salesTab === 'returns' && (
        <div className="bg-[#f0f0f0] p-3 rounded-lg border-2 border-emerald-600 shadow-md text-slate-800 font-sans space-y-4">
          
          <div className="text-xs font-bold text-slate-700 uppercase tracking-widest border-b border-slate-300 pb-1 flex items-center justify-between">
            <span>Sales Return / Credit Note Entry Terminal</span>
            <span className="text-emerald-700 font-black">WAREHOUSE INCOMING</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-3">
            
            {/* Left side: Client return info, Product return info, Grid, Maroon red total */}
            <div className="lg:col-span-4 space-y-3">
              
              {/* Client Return Information Box */}
              <div className="bg-[#f5f5f5] border border-slate-300 p-2 rounded shadow-sm">
                <div className="text-[11px] font-bold text-emerald-800 border-b border-slate-200 pb-1 mb-2 uppercase tracking-wider">
                  Client Return Information
                </div>
                <div className="grid grid-cols-1 md:grid-cols-5 gap-2 text-xs">
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Return ID</label>
                    <input
                      type="text"
                      readOnly
                      value={retInvoiceNo}
                      className="w-full bg-[#ffffe2] text-slate-700 font-bold border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Return Date</label>
                    <input
                      type="date"
                      value={retDate}
                      onChange={(e) => setRetDate(e.target.value)}
                      className="w-full bg-[#ffffe2] text-slate-800 font-semibold border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Customer Name</label>
                    <select
                      value={retCustomerId}
                      onChange={(e) => setRetCustomerId(e.target.value)}
                      className="w-full bg-[#ffffe2] text-slate-800 font-bold border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    >
                      <option value="">-- Select Customer --</option>
                      {customers.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Ref Invoice No</label>
                    <input
                      type="text"
                      value={retInvoiceRef}
                      onChange={(e) => setRetInvoiceRef(e.target.value)}
                      placeholder="INV-XXXXXX"
                      className="w-full bg-white text-slate-800 border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Reason for return</label>
                    <select
                      value={retReason}
                      onChange={(e) => setRetReason(e.target.value)}
                      className="w-full bg-[#ffffe2] text-slate-850 border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    >
                      <option value="Damaged Tiles / Chips">Damaged Tiles / Chips</option>
                      <option value="Wrong Size Shipped">Wrong Size Shipped</option>
                      <option value="Defective Finish">Defective Finish</option>
                      <option value="Customer Changed Mind">Customer Changed Mind</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Product Return Information Box */}
              <div className="bg-[#f5f5f5] border border-slate-300 p-2 rounded shadow-sm">
                <div className="text-[11px] font-bold text-emerald-800 border-b border-slate-200 pb-1 mb-2 uppercase tracking-wider">
                  Product Return Details
                </div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-2 text-xs">
                  <div className="md:col-span-2">
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Product Name</label>
                    <select
                      value={retProductId}
                      onChange={(e) => handleSelectProductForReturn(e.target.value)}
                      className="w-full bg-[#ffffe2] text-slate-800 font-bold border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    >
                      <option value="">-- Select Return Item --</option>
                      {products.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} (৳{p.price}/unit)
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Return Qty</label>
                    <input
                      type="number"
                      min="1"
                      value={retQty}
                      onChange={(e) => setRetQty(parseInt(e.target.value) || 1)}
                      className="w-full bg-white text-slate-800 border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-500 font-semibold mb-0.5">Refund Rate</label>
                    <input
                      type="number"
                      readOnly
                      value={retRefundRate}
                      className="w-full bg-[#ffffe2] text-slate-700 font-bold border border-slate-300 px-2 py-1 rounded-sm focus:outline-none text-[11px]"
                    />
                  </div>
                </div>
              </div>

              {/* Return Cart Table Grid */}
              <div className="border border-slate-300 rounded overflow-hidden shadow-sm bg-white">
                <div className="bg-[#3f3f46] text-white px-2 py-1 text-[11px] font-mono flex items-center justify-between select-none">
                  <span>Return Line Items Grid</span>
                  <span className="text-[10px] text-slate-300">Auto credit note balance updates</span>
                </div>
                
                <div className="overflow-x-auto max-h-[220px]">
                  <table className="w-full text-left text-[11px] border-collapse">
                    <thead>
                      <tr className="bg-[#eeeeee] border-b border-slate-300 text-slate-600 font-bold">
                        <th className="py-1 px-2 border-r border-slate-300 w-16">No</th>
                        <th className="py-1 px-2 border-r border-slate-300">SKU Code</th>
                        <th className="py-1 px-2 border-r border-slate-300">Product</th>
                        <th className="py-1 px-2 border-r border-slate-300 text-right">Return Qty</th>
                        <th className="py-1 px-2 border-r border-slate-300 text-right">Refund Rate</th>
                        <th className="py-1 px-2 text-right">NetRefund</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 font-mono">
                      {retCart.map((item, idx) => (
                        <tr key={idx} className="hover:bg-slate-50 text-slate-700">
                          <td className="py-1.5 px-2 border-r border-slate-200">0{idx + 1}</td>
                          <td className="py-1.5 px-2 border-r border-slate-200">{item.sku}</td>
                          <td className="py-1.5 px-2 border-r border-slate-200 font-bold">{item.name}</td>
                          <td className="py-1.5 px-2 border-r border-slate-200 text-right font-bold text-emerald-800">{item.qty}</td>
                          <td className="py-1.5 px-2 border-r border-slate-200 text-right">৳{item.rate.toLocaleString()}</td>
                          <td className="py-1.5 px-2 text-right font-bold text-slate-800">৳{item.subtotal.toLocaleString()}</td>
                        </tr>
                      ))}
                      {retCart.length === 0 && (
                        <tr>
                          <td colSpan={6} className="py-8 text-center text-slate-400 font-bold bg-[#fafafa]">
                            Select return products above and click 'Add Return Line Item'
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Maroon Total Bar */}
              <div className="bg-[#800000] text-white p-2 rounded shadow-inner text-center font-black tracking-wider text-xs select-none">
                Total Credit Note Value : {retCart.reduce((sum, item) => sum + item.subtotal, 0).toLocaleString()} BDT
              </div>

            </div>

            {/* Right side: Actions Sidebar */}
            <div className="space-y-3 lg:col-span-1 flex flex-col justify-between">
              
              <div className="bg-[#f5f5f5] border border-slate-300 rounded p-2 shadow-sm text-xs space-y-2">
                <div className="font-bold text-slate-600 border-b border-slate-200 pb-0.5 uppercase text-[10px]">
                  Warehouse Policy
                </div>
                <p className="text-[10px] text-slate-500 leading-relaxed">
                  All returns undergo quality review before warehouse restock. Refund is disbursed as client Credit Note balance automatically.
                </p>
                <div className="flex items-center gap-1.5 bg-amber-50 text-amber-800 p-1.5 rounded border border-amber-100 text-[10px]">
                  <AlertTriangle className="h-3.5 w-3.5 text-amber-600 shrink-0" />
                  <span>Restores item stock counts!</span>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  onClick={handleAddReturnRow}
                  className="w-full bg-gradient-to-b from-[#fdfdfd] to-[#d6d6d6] hover:from-white hover:to-[#e1e1e1] border border-[#a6a6a6] text-slate-800 text-xs font-black py-2 rounded shadow-[inset_0_1px_0_rgba(255,255,255,0.9),0_1px_3px_rgba(0,0,0,0.15)] active:shadow-inner cursor-pointer text-center uppercase tracking-wider"
                >
                  Add Return Line
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setRetCart([]);
                    alert('Return line items cleared successfully.');
                  }}
                  className="w-full bg-gradient-to-b from-[#fdfdfd] to-[#d6d6d6] hover:from-white hover:to-[#e1e1e1] border border-[#a6a6a6] text-slate-800 text-xs font-black py-2 rounded shadow-[inset_0_1px_0_rgba(255,255,255,0.9),0_1px_3px_rgba(0,0,0,0.15)] active:shadow-inner cursor-pointer text-center uppercase tracking-wider"
                >
                  Clear Fields
                </button>

                <button
                  type="button"
                  onClick={handleSaveSalesReturn}
                  className="w-full bg-gradient-to-b from-[#fbfbfb] to-[#c5c5c5] hover:from-white hover:to-[#dbdbdb] border border-[#9b9b9b] text-emerald-900 text-xs font-black py-2.5 rounded shadow-[inset_0_1px_0_rgba(255,255,255,0.95),0_2px_4px_rgba(0,0,0,0.2)] active:shadow-inner cursor-pointer text-center uppercase tracking-widest border-2"
                >
                  Save Return (Credit Note)
                </button>
              </div>

            </div>

          </div>

          {/* Historical Credit Note Ledger view */}
          <div className="bg-white border border-slate-300 rounded shadow-sm overflow-hidden">
            <div className="bg-[#3f3f46] text-white px-3 py-1 font-mono text-[11px] font-bold flex items-center justify-between">
              <span>Sales Returns Ledger Archive (Historical Log)</span>
              <span className="text-[10px] text-slate-300">Comprehensive Return Logs</span>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead>
                  <tr className="bg-[#f1f1f1] border-b border-slate-300 text-slate-600 font-bold">
                    <th className="py-2 px-3 border-r border-slate-200">Return ID</th>
                    <th className="py-2 px-3 border-r border-slate-200">Source Invoice</th>
                    <th className="py-2 px-3 border-r border-slate-200">Customer Name</th>
                    <th className="py-2 px-3 border-r border-slate-200">Date Processed</th>
                    <th className="py-2 px-3 border-r border-slate-200">Reason</th>
                    <th className="py-2 px-3 text-right">Value Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {salesReturns.map((ret) => (
                    <tr key={ret.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-2 px-3 border-r border-slate-200 font-bold text-indigo-700">{ret.id.toUpperCase()}</td>
                      <td className="py-2 px-3 border-r border-slate-200 font-semibold text-slate-600">{ret.invoiceNo}</td>
                      <td className="py-2 px-3 border-r border-slate-200 font-bold text-slate-800">{ret.customerName}</td>
                      <td className="py-2 px-3 border-r border-slate-200 text-slate-500 font-medium">{ret.date}</td>
                      <td className="py-2 px-3 border-r border-slate-200">
                        <span className="font-bold text-rose-600 flex items-center gap-1 text-[11px]">
                          <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                          <span>{ret.reason}</span>
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right font-black text-rose-600">৳{ret.amount.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* 3. CASH COLLECTION HISTORY */}
      {salesTab === 'collection' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold text-slate-800 font-display">Client Collections History</h2>
              <p className="text-xs text-slate-400 mt-1">Audit historic payments received from clients settling outstanding credit dues.</p>
            </div>
            <button
              onClick={() => {
                if (customers.filter(c => c.outstandingBalance > 0).length === 0) {
                  alert('All customers have a clean ledger with zero outstanding balance!');
                  return;
                }
                setShowCollectionModal(customers.filter(c => c.outstandingBalance > 0)[0]);
                setCollectVal('5000');
              }}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs px-4 py-2.5 rounded-lg shadow-md cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>Post Collection Receipt</span>
            </button>
          </div>

          <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-semibold bg-slate-50/50 uppercase tracking-wider">
                  <th className="py-3.5 px-6">Collection Voucher No</th>
                  <th className="py-3.5 px-6">Customer Member</th>
                  <th className="py-3.5 px-6">Settlement Date</th>
                  <th className="py-3.5 px-6">Collection Mode</th>
                  <th className="py-3.5 px-6 text-right">Collected Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {collectionsHistory.map((col) => (
                  <tr key={col.id} className="hover:bg-slate-50/30 transition-colors">
                    <td className="py-4 px-6 font-mono font-bold text-indigo-600">{col.id.toUpperCase()}</td>
                    <td className="py-4 px-6 font-bold text-slate-800">{col.customerName}</td>
                    <td className="py-4 px-6 text-slate-500 font-medium">{col.date}</td>
                    <td className="py-4 px-6">
                      <span className="px-2.5 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-100 text-[10px] font-bold uppercase">{col.method}</span>
                    </td>
                    <td className="py-4 px-6 text-right font-black text-emerald-600">৳{col.amount.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. CUSTOMER GROUPS VIEW */}
      {salesTab === 'customer_groups' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold text-slate-800 font-display">Customer Segmentation & Terms</h2>
              <p className="text-xs text-slate-400 mt-1">Configure client flat discount rules, ceiling credit limits, and classifications.</p>
            </div>
            <button
              onClick={() => setShowGroupModal(true)}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs px-4 py-2.5 rounded-lg shadow-md cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>Add Customer Group</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {customerGroups.map((g) => (
              <div key={g.name} className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4 hover:shadow-md transition-shadow relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1.5 bg-indigo-600" />
                <div className="flex justify-between items-start">
                  <span className="px-2.5 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-full text-[10px] font-bold">Standard</span>
                  <span className="text-[10px] font-bold text-indigo-600 uppercase font-mono">{g.discountRate}% Flat Disc.</span>
                </div>

                <div>
                  <h3 className="font-bold text-slate-800 text-sm">{g.name}</h3>
                  <p className="text-[10px] text-slate-400 mt-0.5 font-semibold">Pre-approved credit terms</p>
                </div>

                <div className="border-t border-slate-50 pt-3 space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-500">
                    <span>Credit Ceiling Limit</span>
                    <span className="font-bold text-slate-800">৳{g.creditLimit.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Active Member Clients</span>
                    <span className="font-bold text-indigo-600">{g.memberCount} Customers</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. MARKETING OFFICERS */}
      {salesTab === 'marketing_officer' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold text-slate-800 font-display">Marketing Officers & Commission</h2>
              <p className="text-xs text-slate-400 mt-1">Audit marketing officer performance, base commission slabs, and pending pay-outs.</p>
            </div>
            <button
              onClick={() => setShowMoModal(true)}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs px-4 py-2.5 rounded-lg shadow-md cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>Add Marketing Officer</span>
            </button>
          </div>

          <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-semibold bg-slate-50/50 uppercase tracking-wider">
                  <th className="py-3.5 px-6">Officer Name</th>
                  <th className="py-3.5 px-6">Corporate Position</th>
                  <th className="py-3.5 px-6 text-center">Commission Slab</th>
                  <th className="py-3.5 px-6 text-right">Total Generated Volume</th>
                  <th className="py-3.5 px-6 text-right">Paid Commission</th>
                  <th className="py-3.5 px-6 text-right">Pending Pay-out</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {marketingOfficers.map((mo) => {
                  const grossComm = (mo.totalSales * mo.commissionRate) / 100;
                  const pending = grossComm - mo.paidCommission;

                  return (
                    <tr key={mo.name} className="hover:bg-slate-50/30 transition-colors">
                      <td className="py-4 px-6 font-bold text-slate-800">{mo.name}</td>
                      <td className="py-4 px-6 font-medium text-slate-500">{mo.designation}</td>
                      <td className="py-4 px-6 text-center font-mono font-bold text-indigo-600">{mo.commissionRate}%</td>
                      <td className="py-4 px-6 text-right font-bold text-slate-800">৳{mo.totalSales.toLocaleString()}</td>
                      <td className="py-4 px-6 text-right font-bold text-emerald-600">৳{mo.paidCommission.toLocaleString()}</td>
                      <td className="py-4 px-6 text-right font-black text-rose-600">৳{pending.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. AGED DUE PAYMENTS REPORT */}
      {salesTab === 'due_report' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-800 font-display">Aged Due Payments Report</h2>
            <p className="text-xs text-slate-400 mt-1">Audit outstanding corporate credits, aging cycles, and overdue durations.</p>
          </div>

          <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-semibold bg-slate-50/50 uppercase tracking-wider">
                  <th className="py-3.5 px-6">Debtor Client Name</th>
                  <th className="py-3.5 px-6">Segment Group</th>
                  <th className="py-3.5 px-6 text-center">Credit Aging Period</th>
                  <th className="py-3.5 px-6 text-right">sanctioned Credit Limit</th>
                  <th className="py-3.5 px-6 text-right">Outstanding Overdue Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {customers.filter(c => c.outstandingBalance > 0).map((c) => {
                  const limit = c.group === 'Wholesale Distributor' ? 100000 : c.group === 'Corporate Account' ? 50000 : 10000;
                  return (
                    <tr key={c.id} className="hover:bg-slate-50/30 transition-colors">
                      <td className="py-4 px-6 font-bold text-slate-800">{c.name}</td>
                      <td className="py-4 px-6 font-semibold text-slate-500">{c.group}</td>
                      <td className="py-4 px-6 text-center">
                        <span className="px-2.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-100 text-[10px] font-bold">15 - 30 Days Overdue</span>
                      </td>
                      <td className="py-4 px-6 text-right font-semibold text-slate-500">৳{limit.toLocaleString()}</td>
                      <td className="py-4 px-6 text-right font-black text-rose-600">৳{c.outstandingBalance.toLocaleString()}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 7. CLIENT EXPENSES LOG */}
      {salesTab === 'client_expense' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-bold text-slate-800 font-display">Client Entertainment Expenses</h2>
              <p className="text-xs text-slate-400 mt-1">Log expenses spent on customer acquisition, entertainment dinners, and conveyances.</p>
            </div>
            <button
              onClick={() => setShowExpenseModal(true)}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs px-4 py-2.5 rounded-lg shadow-md cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>Log Client Expense</span>
            </button>
          </div>

          <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-semibold bg-slate-50/50 uppercase tracking-wider">
                  <th className="py-3.5 px-6">Expense ID</th>
                  <th className="py-3.5 px-6">Associated Client</th>
                  <th className="py-3.5 px-6">Date Processed</th>
                  <th className="py-3.5 px-6">Expenditure Reason</th>
                  <th className="py-3.5 px-6 text-right">Value Expended</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {clientExpenses.map((exp) => (
                  <tr key={exp.id} className="hover:bg-slate-50/30 transition-colors">
                    <td className="py-4 px-6 font-mono font-bold text-indigo-600">{exp.id.toUpperCase()}</td>
                    <td className="py-4 px-6 font-bold text-slate-800">{exp.customerName}</td>
                    <td className="py-4 px-6 text-slate-500 font-medium">{exp.date}</td>
                    <td className="py-4 px-6 text-slate-500 font-semibold">{exp.reason}</td>
                    <td className="py-4 px-6 text-right font-black text-rose-600">৳{exp.amount.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 8. RED LIST DEFULTER LIST */}
      {salesTab === 'red_list_customers' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-800 font-display">Red-Listed Defaulters (Dues Alert)</h2>
            <p className="text-xs text-rose-500 mt-1 font-bold">List of critical debtors who breached pre-approved credit ceiling limits or delayed payments beyond 90 days.</p>
          </div>

          <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-rose-400 font-semibold bg-rose-50/20 uppercase tracking-wider">
                  <th className="py-3.5 px-6">Customer Member</th>
                  <th className="py-3.5 px-6">Overdue Balance</th>
                  <th className="py-3.5 px-6 text-center">Defaulter Period</th>
                  <th className="py-3.5 px-6 text-right">sanctioned limit</th>
                  <th className="py-3.5 px-6 text-center">Credit Freeze status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {customers.filter(c => c.outstandingBalance > 500).map((c) => (
                  <tr key={c.id} className="bg-rose-50/10 hover:bg-rose-50/20 transition-colors">
                    <td className="py-4 px-6 font-bold text-slate-800">{c.name}</td>
                    <td className="py-4 px-6 font-black text-rose-600">৳{c.outstandingBalance.toLocaleString()}</td>
                    <td className="py-4 px-6 text-center font-mono font-bold text-rose-500">90+ Days Delay</td>
                    <td className="py-4 px-6 text-right font-semibold text-slate-500">৳10,000</td>
                    <td className="py-4 px-6 text-center">
                      <span className="px-2.5 py-0.5 rounded bg-rose-600 text-white text-[10px] font-bold border border-rose-700 animate-pulse">CREDIT BLOCKED</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 9. PRODUCT WISE TOTAL SALES */}
      {salesTab === 'product_wise_report' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-800 font-display">Product wise Sales & Revenue Report</h2>
            <p className="text-xs text-slate-400 mt-1">Audit individual item volume sold, gross profit contribution margins, and market demands.</p>
          </div>

          <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-semibold bg-slate-50/50 uppercase tracking-wider">
                  <th className="py-3.5 px-6">Product Catalog Item</th>
                  <th className="py-3.5 px-6">SKU Code</th>
                  <th className="py-3.5 px-6">Category Segment</th>
                  <th className="py-3.5 px-6 text-center">Quantity Dispatched</th>
                  <th className="py-3.5 px-6 text-right">Price per Unit</th>
                  <th className="py-3.5 px-6 text-right">Gross Sales Invoiced</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {products.map((p, idx) => {
                  const qtySold = 10 + (idx * 4);
                  const salesRev = qtySold * p.price;

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/30 transition-colors">
                      <td className="py-4 px-6 font-bold text-slate-800">{p.name}</td>
                      <td className="py-4 px-6 font-mono font-semibold text-indigo-600">{p.sku}</td>
                      <td className="py-4 px-6 text-slate-500 font-medium">{p.category}</td>
                      <td className="py-4 px-6 text-center font-bold text-slate-700">{qtySold} Units</td>
                      <td className="py-4 px-6 text-right font-medium text-slate-500">৳{p.price.toLocaleString()}</td>
                      <td className="py-4 px-6 text-right font-black text-slate-800">৳{salesRev.toLocaleString()}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================
          NEW ADDITIONAL OVERLAY MODALS
          ========================================================= */}

      {/* 1. Record Sale Order Modal */}
      {showSoModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="px-5 py-3 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Book Sale Order</h4>
              <button onClick={() => setShowSoModal(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">✕</button>
            </div>
            <form onSubmit={(e) => {
              e.preventDefault();
              if (!newSoCust || !newSoAmt) return;
              const newO = {
                id: `so_dyn_${Date.now()}`,
                orderNo: `SO-2026-0${100 + saleOrders.length}`,
                customerName: newSoCust,
                date: new Date().toISOString().split('T')[0],
                amount: parseFloat(newSoAmt),
                status: 'Pending Delivery',
              };
              setSaleOrders([newO, ...saleOrders]);
              setNewSoCust('');
              setNewSoAmt('');
              setShowSoModal(false);
              alert('Sale order booked in system!');
            }} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Customer Client Name *</label>
                <input
                  type="text" required placeholder="e.g. Arif Hossain" value={newSoCust}
                  onChange={(e) => setNewSoCust(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Estimated Value Amount (৳) *</label>
                <input
                  type="number" required placeholder="25000" value={newSoAmt}
                  onChange={(e) => setNewSoAmt(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none font-bold"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowSoModal(false)} className="px-3.5 py-1.5 border border-slate-200 text-slate-500 rounded-md text-xs hover:bg-slate-50 cursor-pointer">Cancel</button>
                <button type="submit" className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-xs font-bold cursor-pointer">Place Order</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. Record Sales Return Modal */}
      {showReturnModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="px-5 py-3 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Record Sales Return Voucher</h4>
              <button onClick={() => setShowReturnModal(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">✕</button>
            </div>
            <form onSubmit={(e) => {
              e.preventDefault();
              if (!newReturnInv || !newReturnCust || !newReturnAmt) return;
              const newRet = {
                id: `sr_dyn_${Date.now()}`,
                invoiceNo: newReturnInv,
                customerName: newReturnCust,
                date: new Date().toISOString().split('T')[0],
                amount: parseFloat(newReturnAmt),
                reason: newReturnReason,
              };
              setSalesReturns([newRet, ...salesReturns]);
              setNewReturnInv('');
              setNewReturnCust('');
              setNewReturnAmt('');
              setShowReturnModal(false);
              alert('Customer return processed! Stock restored and client account credited.');
            }} className="p-5 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Source Invoice *</label>
                  <input
                    type="text" required placeholder="e.g. INV-007401" value={newReturnInv}
                    onChange={(e) => setNewReturnInv(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Customer Name *</label>
                  <input
                    type="text" required placeholder="Arif Hossain" value={newReturnCust}
                    onChange={(e) => setNewReturnCust(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Value Amount (৳) *</label>
                  <input
                    type="number" required placeholder="1200" value={newReturnAmt}
                    onChange={(e) => setNewReturnAmt(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none text-rose-600 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Return Reason</label>
                  <select value={newReturnReason} onChange={(e) => setNewReturnReason(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none cursor-pointer">
                    <option>Packaging damaged</option>
                    <option>Defective batch</option>
                    <option>Duplicate dispatch</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowReturnModal(false)} className="px-3.5 py-1.5 border border-slate-200 text-slate-500 rounded-md text-xs hover:bg-slate-50 cursor-pointer">Cancel</button>
                <button type="submit" className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-xs font-bold cursor-pointer">Authorize Return</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. Add Customer Group Modal */}
      {showGroupModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="px-5 py-3 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Add Customer Segment Group</h4>
              <button onClick={() => setShowGroupModal(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">✕</button>
            </div>
            <form onSubmit={(e) => {
              e.preventDefault();
              if (!newGroupName) return;
              const newG = {
                name: newGroupName,
                discountRate: parseFloat(newGroupDisc) || 0,
                creditLimit: parseFloat(newGroupCredit) || 10000,
                memberCount: 0,
              };
              setCustomerGroups([...customerGroups, newG]);
              setNewGroupName('');
              setNewGroupDisc('0');
              setNewGroupCredit('10000');
              setShowGroupModal(false);
              alert('Customer group created successfully!');
            }} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Group Title *</label>
                <input
                  type="text" required placeholder="e.g. Platinum Retailers" value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Flat Discount (%)</label>
                  <input
                    type="number" min="0" max="100" placeholder="5" value={newGroupDisc}
                    onChange={(e) => setNewGroupDisc(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-center"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Credit Limit (৳)</label>
                  <input
                    type="number" placeholder="25000" value={newGroupCredit}
                    onChange={(e) => setNewGroupCredit(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-center font-bold text-indigo-600"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowGroupModal(false)} className="px-3.5 py-1.5 border border-slate-200 text-slate-500 rounded-md text-xs hover:bg-slate-50 cursor-pointer">Cancel</button>
                <button type="submit" className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-xs font-bold cursor-pointer">Save Segment</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. Add Marketing Officer Modal */}
      {showMoModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="px-5 py-3 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Add Marketing Personnel</h4>
              <button onClick={() => setShowMoModal(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">✕</button>
            </div>
            <form onSubmit={(e) => {
              e.preventDefault();
              if (!newMoName) return;
              const newMo = {
                name: newMoName,
                designation: newMoDesig,
                commissionRate: parseFloat(newMoComm) || 2.0,
                totalSales: 0,
                paidCommission: 0,
              };
              setMarketingOfficers([...marketingOfficers, newMo]);
              setNewMoName('');
              setShowMoModal(false);
              alert('Marketing Officer saved in system!');
            }} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Representative Name *</label>
                <input
                  type="text" required placeholder="e.g. Shajib Iqbal" value={newMoName}
                  onChange={(e) => setNewMoName(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Company Grade</label>
                  <select value={newMoDesig} onChange={(e) => setNewMoDesig(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none cursor-pointer">
                    <option>Marketing Executive</option>
                    <option>Senior Marketing Officer</option>
                    <option>Area Sales Lead</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Commission rate (%)</label>
                  <input
                    type="number" step="0.1" placeholder="2.5" value={newMoComm}
                    onChange={(e) => setNewMoComm(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-center"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowMoModal(false)} className="px-3.5 py-1.5 border border-slate-200 text-slate-500 rounded-md text-xs hover:bg-slate-50 cursor-pointer">Cancel</button>
                <button type="submit" className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-xs font-bold cursor-pointer">Save Position</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 5. Log Client Expense Modal */}
      {showExpenseModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="px-5 py-3 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Log Client Acquisition Expense</h4>
              <button onClick={() => setShowExpenseModal(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">✕</button>
            </div>
            <form onSubmit={(e) => {
              e.preventDefault();
              if (!newExpCust || !newExpAmt) return;
              const newEx = {
                id: `exp_dyn_${Date.now()}`,
                customerName: newExpCust,
                date: new Date().toISOString().split('T')[0],
                amount: parseFloat(newExpAmt),
                reason: newExpReason,
              };
              setClientExpenses([newEx, ...clientExpenses]);
              setNewExpCust('');
              setNewExpAmt('');
              setNewExpReason('Entertainment');
              setShowExpenseModal(false);
              alert('Acquisition expense successfully recorded against accounts.');
            }} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Target Client Customer *</label>
                <input
                  type="text" required placeholder="e.g. Salim Mahmud" value={newExpCust}
                  onChange={(e) => setNewExpCust(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Amount Spent (৳) *</label>
                  <input
                    type="number" required placeholder="1500" value={newExpAmt}
                    onChange={(e) => setNewExpAmt(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none text-rose-600 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Expense Reason</label>
                  <select value={newExpReason} onChange={(e) => setNewExpReason(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none cursor-pointer">
                    <option>Entertainment dinner</option>
                    <option>Business travel/conveyance</option>
                    <option>Corporate gift hampers</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowExpenseModal(false)} className="px-3.5 py-1.5 border border-slate-200 text-slate-500 rounded-md text-xs hover:bg-slate-50 cursor-pointer">Cancel</button>
                <button type="submit" className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-xs font-bold cursor-pointer">Log Expense</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quick Add Customer Modal */}
      {showCustModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="px-5 py-3.5 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wide">Add New Customer</h3>
              <button onClick={() => setShowCustModal(false)} className="text-slate-400 hover:text-slate-600 font-bold cursor-pointer">✕</button>
            </div>
            <form onSubmit={handleAddCustSubmit} className="p-5 space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Customer Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Salim Mahmud"
                  value={custName}
                  onChange={(e) => setCustName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs focus:outline-none focus:border-indigo-600"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Phone Number *</label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. 01712xxxxxx"
                  value={custPhone}
                  onChange={(e) => setCustPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs focus:outline-none focus:border-indigo-600"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Email Address</label>
                <input
                  type="email"
                  placeholder="salim@gmail.com"
                  value={custEmail}
                  onChange={(e) => setCustEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs focus:outline-none focus:border-indigo-600"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Group Classification</label>
                <select
                  value={custGroup}
                  onChange={(e) => setCustGroup(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs focus:outline-none cursor-pointer"
                >
                  <option value="Regular Retail">Regular Retail</option>
                  <option value="Wholesale Contractor">Wholesale Contractor</option>
                  <option value="Premium Client">Premium Client</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowCustModal(false)}
                  className="px-4 py-1.5 border border-slate-200 text-slate-500 rounded-lg text-xs hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold cursor-pointer shadow"
                >
                  Save Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Record Collection (Pay outstanding) Modal */}
      {showCollectionModal !== null && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full overflow-hidden border border-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="px-5 py-3 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Record Cash Collection</h4>
              <button onClick={() => setShowCollectionModal(null)} className="text-slate-400 hover:text-slate-600 cursor-pointer">✕</button>
            </div>
            <form onSubmit={handleRecordCollectionSubmit} className="p-5 space-y-4">
              <div>
                <p className="text-xs text-slate-500 font-semibold mb-3">
                  Collect payment from:{' '}
                  <span className="font-extrabold text-slate-800">{showCollectionModal.name}</span>
                </p>
                <div className="flex justify-between text-xs bg-slate-50 p-3 rounded-lg border border-slate-100 mb-4">
                  <span className="text-slate-500">Outstanding Credit:</span>
                  <span className="font-bold text-rose-600">৳{showCollectionModal.outstandingBalance.toLocaleString()}</span>
                </div>

                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Amount Received (৳) *
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  max={showCollectionModal.outstandingBalance}
                  value={collectVal}
                  onChange={(e) => setCollectVal(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none focus:border-indigo-600 font-extrabold text-indigo-600"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowCollectionModal(null)}
                  className="px-3.5 py-1.5 border border-slate-200 text-slate-500 rounded-md text-xs hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-xs font-bold cursor-pointer"
                >
                  Record Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* High-Fidelity Printable Sales Invoice Modal */}
      {invoiceToPrint !== null && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-100 animate-in fade-in zoom-in-95 duration-150 my-8">
            {/* Top Modal Controls */}
            <div className="px-6 py-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between no-print">
              <span className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
                <FileSpreadsheet className="h-4 w-4 text-indigo-500" />
                <span>Sales Receipt Generated</span>
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm transition-all cursor-pointer"
                >
                  <Printer className="h-3.5 w-3.5" />
                  <span>Print (Ctrl+P)</span>
                </button>
                <button
                  onClick={() => setInvoiceToPrint(null)}
                  className="text-slate-400 hover:text-slate-600 font-bold px-2 py-1 cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Printable Receipt Paper Container */}
            <div className="p-8 space-y-6 text-xs text-slate-700" id="printable-area">
              {/* Receipt Header */}
              <div className="flex justify-between items-start">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <div className="h-8 w-8 rounded-lg bg-indigo-600 text-white font-black text-base flex items-center justify-center shadow">
                      A
                    </div>
                    <span className="text-base font-black font-display text-slate-800 tracking-tight">AXIOM ERP</span>
                  </div>
                  <p className="font-bold text-slate-800">M/S Madani Traders</p>
                  <p className="text-slate-400 leading-relaxed font-medium">
                    Dhaka Sadar Head Office, Dhaka<br />
                    Phone: 01712345678 | Email: sales@madanitraders.com
                  </p>
                </div>
                <div className="text-right space-y-1.5">
                  <span className="text-lg font-black font-display text-slate-800 tracking-tight block">INVOICE</span>
                  <p className="font-mono font-bold text-indigo-600 text-sm">{invoiceToPrint.invoiceNo}</p>
                  <p className="text-slate-500 font-semibold">Date: {invoiceToPrint.date}</p>
                  <p className="text-slate-500 font-semibold uppercase">Status: <span className="text-emerald-600 font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">{invoiceToPrint.paymentMethod}</span></p>
                </div>
              </div>

              <div className="border-t border-slate-100 my-4"></div>

              {/* Billed To Details */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">CUSTOMER INFORMATION</span>
                  <p className="font-bold text-slate-800 text-sm">{invoiceToPrint.customerName}</p>
                  <p className="text-slate-500 font-semibold font-mono mt-0.5">Phone: {customers.find(c => c.id === invoiceToPrint.customerId)?.phone || 'N/A'}</p>
                  <p className="text-slate-400 font-medium">{customers.find(c => c.id === invoiceToPrint.customerId)?.email || ''}</p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">BRANCH LOCATION</span>
                  <p className="font-bold text-slate-800">Main Warehouse Terminal</p>
                  <p className="text-slate-400 mt-0.5">M/S Madani Traders, Dhaka Branch</p>
                </div>
              </div>

              {/* Items Table */}
              <div className="mt-6">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase tracking-wider bg-slate-50">
                      <th className="py-2.5 px-3">Product Catalog Item</th>
                      <th className="py-2.5 px-3 text-center">Unit Price</th>
                      <th className="py-2.5 px-3 text-center">Quantity</th>
                      <th className="py-2.5 px-3 text-right">Subtotal</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {invoiceToPrint.items.map((item, index) => (
                      <tr key={index}>
                        <td className="py-3 px-3 font-bold text-slate-800">{item.name}</td>
                        <td className="py-3 px-3 text-center text-slate-600">৳{item.price.toLocaleString()}</td>
                        <td className="py-3 px-3 text-center text-slate-600 font-semibold">{item.quantity}</td>
                        <td className="py-3 px-3 text-right font-bold text-slate-800">৳{item.subtotal.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Receipt Totals Summary */}
              <div className="border-t border-slate-200 mt-6 pt-4 flex justify-end">
                <div className="w-64 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-500">
                    <span>Subtotal:</span>
                    <span className="font-semibold text-slate-800">৳{invoiceToPrint.subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>VAT / TAX ({invoiceToPrint.taxRate}%):</span>
                    <span className="font-semibold text-slate-800">৳{invoiceToPrint.taxAmount.toLocaleString()}</span>
                  </div>
                  {invoiceToPrint.discount > 0 && (
                    <div className="flex justify-between text-emerald-600 font-medium">
                      <span>Discount:</span>
                      <span>-৳{invoiceToPrint.discount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="border-t border-slate-200 my-1"></div>
                  <div className="flex justify-between text-sm">
                    <span className="font-bold text-slate-800">Grand Total:</span>
                    <span className="font-black text-indigo-600 text-base font-display">৳{invoiceToPrint.total.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Receipt Footer Notes */}
              <div className="border-t border-dashed border-slate-200 pt-6 mt-8 text-center text-slate-400 space-y-1">
                <p className="font-bold text-slate-500">Thank you for your business!</p>
                <p className="text-[10px] font-medium">System generated digital tax slip, no physical signature required.</p>
                <p className="text-[9px] font-mono mt-2 text-slate-300 uppercase tracking-widest">Axiom Cloud ERP Suite</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
